export const resetCart = () => {
  return {
    type: "RESET_CART"
  };
};
